*document in progress*
* explain why *value* and *object* is fundamental functions.
* write about *Growable* extension