*document in progress*
* NoError,
* BUFFER_OVERFLOW,
* INVALID_BUFFER_DATA
* write what happens when data is corrupted
* how growable effect error codes when deserializing old data format.
