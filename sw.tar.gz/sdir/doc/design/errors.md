errors handling design
usage of NotDefinedType, and how it helps to reduce error stack